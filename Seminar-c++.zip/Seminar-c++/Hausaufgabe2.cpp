// HKI C++ Programmierpraktikum SoSe 2017 - 20.04.2017
#include <iostream>
using namespace std;

void verbinden(char *a, char *b)
{
   char zk3[100];
   
   int i, int j;
   for(i=0; a[i]!='\0'; i++) {
	zk3[i]=a[i];
	}
   for(j=0; b[j]!='\0'; j++) {
   zk3 [i+j]=b[j];
   }
   zk3 [i+j]='\0';
   cout << a << " + " << b << " = " << zk3 << endl;
}

int main()
{
   int n = 10;
   char zk1[n], zk2[n];
   cout << "Bitte geben Sie eine beliebig lange erste Zeichenkette ein:";
   cin >> zk1;
   cout << "Bitte geben Sie eine beliebig lange zweite Zeichenkette ein:";
   cin >> zk2;

   verbinden(zk1,zk2);

   return 0;
}