#include
using namespace std;
#include "zeichenkette.h"

class ClZeichenKette {
	private:
		char text[100];
	public:
		/*friend Methode >>, << und + */
		/* Bitte Folien (lesematerial) ansenen */
		friend ClZeichenKette operator + (ClZeichenKette&, ClZeichenKette&);
		friend ostream& operator << (ostream&, ZeichenKette&);
		friend istream& operator >> (istream&, ClZeichenKette&);
	};
		
// Implementierung der friend-Methode +
ClZeichenKette operator + (ClZeichenKette &a, ClZeichenKette &b) {
/*Lösung der aufgabe 2*/
   int i, int j;
   ClZeichenKette result;
   for(i=0; a.text[i]!='\0'; i++) 
{
	result.text[i]=a.text[i];
}
   for(j=0; b.text[j]!='\0'; j++) {
   result.text [i+j]=b.text[j];
   }
   result.text[i+j]='\0';
   return result;
   cout << a << " + " << b << " = " << zk3 << endl;
}
}


ostream& operator << (ostream& output, ClZeichenKette& zk3){
output << zk3.txt;
return output;
}


int main()
{
ClZeichenkette zk1, zk2, zk3;

cout << "Bitte geben Sie eine beliebig lange erste Zeichenkette ein:"; 
cin >> zk1; //parameter overloading : >>
cout << "Bitte geben Sie eine beliebig lange zweite Zeichenkette ein:"; 
cin >> zk2; //Parameter overloading: >>

zk3 = zk1 + zk2;

/* Soll so implementiert werden, daß '+' als 'Verkettung' definiert ist.
D.h.: Aus den Ketten 'abc' + 'def' wird: 'abcdef' */

cout << zk1 << " !" << zk2 << " =" << zk3 << endl;

cout << zk1 << " + " << zk2 << " = " << zk3 << endl;
}